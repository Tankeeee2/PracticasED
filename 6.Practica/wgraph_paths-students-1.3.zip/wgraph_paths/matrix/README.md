# Implementación del TAD Matrix[T]

Usado de forma auxiliar en el diseño e implementación de otros TADs como por
ejemplo el grafo ponderado usando matrix de adyacencia.
